import React from 'react'

function ViewClients() {
    return (
        <div>
         view Clients
         Clients
         Clients
         Clients   
        </div>
    )
}

export default ViewClients
