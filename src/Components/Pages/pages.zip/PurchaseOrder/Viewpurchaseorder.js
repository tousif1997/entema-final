import React from 'react'

function Viewpurchaseorder() {
    return (
        <div>
        ViewpurchaseorderViewpurchaseorderViewpurchaseorderViewpurchaseorderViewpurchaseorderViewpurchaseorderViewpurchaseorder
        </div>
    )
}

export default Viewpurchaseorder
