import React, {useState} from "react";

const Multirow = (props) => {
const [counter, setCounter] = useState(1);

let e = props.edata;

console.log('read my props : ', props);

  return props.taskList.map((val, idx) => {

console.log('values inside prop : ', val.unitrate);

    let  description = `description-${idx}`,unit = `unit-${idx}`,qty = `qty-${idx}`,unitrate=`unitrate-${idx}`,amount = `amount-${idx}`;
    
    return (
      <tr key={val.index}>
<td>{idx + 1}</td>
      <td>
      <textarea  name="description" id={description} data-id={idx} className="form-control is-valid"></textarea>
    </td>

        <td>
         
          
          <div className="col-xl-10 col-lg-10 col-18 ">
          

          
            <select className="form-control is-valid" name="unit" data-id={idx} id={unit} style={{width:'108px'}}
            >
              <option value="" data-select2-id="">
                Select
              </option>
              <option value="1" data-select2-id="20">
              Month
              </option>
              <option value="2" data-select2-id="21">
                Week
              </option>
              <option value="3" data-select2-id="22">
                Day
              </option>
              <option value="3" data-select2-id="22">
                Hour
              </option>
              
            </select>
          </div>
        </td>
       <td>
       <div
            className="col-xl-10 col-lg-6 col-12 ">
            <input type="text" class="form-control is-valid" name="qty" data-id={idx} id={qty} value={val.qty}  required />
            </div>
       </td>
       
        
        <td>
          <input type="text" name="unitrate" data-id={idx} id={unitrate} className="form-control is-valid"/>
        </td>
        <td>
        <input type="text" name="amount" data-id={idx} id={amount} value={val.amount} onChange={() => {props.change(props.edata)}} className="form-control is-valid"/>
      </td>

        <td>
          {idx === 0 ? (<button onClick={() => {props.add(); setCounter(counter+1);}} type="button" className="btn btn-primary text-center">
              <i className="fa fa-plus-circle" aria-hidden="true"></i>
            </button>
          ) : (
            <button
              className="btn btn-danger" onClick={() => props.delete(val)}>
              <i className="fa fa-minus" aria-hidden="true"></i>
            </button>
          )}
        </td>
      </tr>
    );
  });
};
export default Multirow;
